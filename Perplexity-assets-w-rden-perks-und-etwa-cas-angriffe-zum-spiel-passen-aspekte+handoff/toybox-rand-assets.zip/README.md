# Toybox Tanks – Arena-Rand

9 source parts: three straight rails (natural wood, muted blue, muted red), plain corner, tower pedestal, cone and pyramid roof caps in red and blue.
Source JS + self-contained HTML inspector + individual SVGs + two rendered PNG previews.

## Geometry
The playable arena is the closed rectangle from (0,0) to (width,height).
All border shapes stay outside that rectangle, except anti-aliased inner outlines extending less than one pixel.
A top rail has local anchor (0,0), length along +X, inner edge y=0 and material at y<0.
Rotate rails by 0/90/180/270 degrees around their corresponding arena corner to form all sides.
The corner piece occupies x<=0 and y<=0 in its default pose. Rotate it around the arena corner. Roof caps share the outer pedestal center; they are decoration only.
Internal material joints are lines, not gaps. No decorative edge rounding changes existing collision normals or original corner rules.
No destruction or collision system is implemented.

## Usage
```js
const options = {width:960,height:560,thickness:36,towers:true,accents:false};
container.innerHTML = ToyboxBorder.svg(options);
// Or preload once for Canvas:
const img = await ToyboxBorder.image(options);
const pad = options.thickness * 1.5 + 8;
ctx.drawImage(img, -pad, -pad);
```
Draw after floor, before important foreground effects. Use the original world-to-screen transformation and logical arena dimensions. Do not resize the arena to fit the decoration. Reserve visible presentation padding outside the arena rather than cropping the border or adding playable space. The sample dimensions are art-study parameters, not authoritative game values.
The SVG image's pixel size equals its viewBox units in this API; the pad offset aligns its arena origin to world (0,0).
Procedural-only renderers can port the simple path definitions to Canvas; this is an optional SVG render source, no engine/framework replacement.

## Validation
SVG XML and PNG integrity checked. JS syntax, generator output and finite numeric output tested with Node.
No real browser, file:// or original game integration test. Example interior blocks are composition aids, not a validated map.
