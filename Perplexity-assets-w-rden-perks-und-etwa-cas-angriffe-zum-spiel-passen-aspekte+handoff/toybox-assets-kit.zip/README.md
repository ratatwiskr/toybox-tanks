# Toybox Tanks – Asset study 01

Design proposal, not an integration or gameplay implementation.

## Deliverables
- toybox-assets.js: dependency-free global `ToyboxAssets` API and source definitions.
- toybox-asset-pruefstand.html: self-contained local inspection page, including all graphics.
- svg/: sixteen individual transparent SVG images, default pose.
- assets.json: source markup, layer rotation roles and metadata.
- PNG previews: contact sheet and illustrative room.

## Coordinates and layers
All assets: viewBox="-64 -64 128 128". Source width/height: 128.
Origin and pivots: (0,0); initial forward direction: right, positive angles clockwise.
Angles in this API: degrees, not simulation radians.
`body` rotates hull/frame; `aim` rotates weapon; `loaded` follows aim and can be hidden.
`fixed` stays screen-aligned. Shadows are separate markup and can be disabled.
For these designs, catapult platform and arm should normally share heading; the independent aim control is provided for inspection, not a new gameplay rule.
Metadata footprints are visual reference only. Preserve original gameplay collision sizes unless a rule change is explicitly approved.
Asset `size` scales the entire 128-unit viewBox, including transparent margins, not just the visible hull.

## Browser use
Load toybox-assets.js with a normal script tag.

```js
const svg = ToyboxAssets.svg('tank-blue', {
  bodyAngle: 20, aimAngle: -35, size: 128, shadow: false
});
container.innerHTML = svg;

// Canvas proof of concept: preload once, do not generate/decode per frame.
const image = await ToyboxAssets.image('tank-blue', {size: 128});
ctx.drawImage(image, x - 64, y - 64);
```

For an animated Canvas renderer, cache body and aim layers independently, apply translate/rotate on the Canvas context and draw them at a common anchor. API `image` is a whole-pose convenience, not a per-frame animation architecture. No atlas, engine or worker required by this study.

## Cork blocks
Three damage states depict the same intact rectangular footprint. No half-open collision shape is implied. When destroyed, the whole block may be removed only if that gameplay decision is approved and propagated consistently to tank movement, projectiles and line of sight. No HP, damage, debris collision or destruction rule is implemented.

## Verification
Python JSON parsing, SVG XML parsing, bounds metadata checks, CairoSVG PNG rendering, Node.js syntax check and SVG generator smoke tests performed. Interactive controls and direct file:// execution have not been run in a real browser. These checks do not prove Canvas integration or browser compatibility. No original project source was provided or modified.

## Art direction
Orthographic top-down. Blue/orange players; charcoal/red enemies. Short screen-oriented contact shadows. No perspective side faces. Decorative wood grain is never collision geometry.
