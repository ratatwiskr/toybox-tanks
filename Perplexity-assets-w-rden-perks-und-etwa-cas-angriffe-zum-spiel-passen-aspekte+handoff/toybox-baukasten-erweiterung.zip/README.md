# Toybox Tanks – Baukasten 02

Erweiterung des Fahrzeug-Asset-Kits, kein Ersatz und keine Spielintegration.

60 SVG-Assets: 10 Formen × 6 Farben.
Formen: Würfel, Quader, langer Quader, Dreiecksblock, Rundblock, Halbrund, Zinnenmauer, Zinnenturm, Kegeldach, Pyramidendach.
Farben: Naturholz, Rot, Blau, Gelb, Grün, Orange.

## Darstellung
Echte Draufsicht; keine schräg dargestellten Vorderansichten der Dächer.
Kegeldach: Kreis mit radialer Schattierung und Spitze im Mittelpunkt.
Pyramidendach: Quadrat mit vier zum Mittelpunkt führenden Dachflächen.
Dächer und Turmkörper teilen denselben Ursprung und können übereinander gezeichnet werden.
Dächer nicht über begehbare Bereiche hängen lassen; keine unsichtbaren Durchgänge impliziert.
Schatten getrennt; Farbe und Glanz sind bewusst zurückhaltend lackiertes Holz.

## Format
viewBox="-64 -64 128 128", Ausgangsrichtung rechts, Winkel in Grad.
visualBounds sind grafische Grenzen, keine fertigen Kollisionsdefinitionen.
Zinnen und Dreiecke brauchen eine explizite Entscheidung über vereinfachte oder genaue Kollisionsformen. Nicht aus SVG-Pfaden automatisch Gameplay ableiten.
Die neuen Bausteine sind fest. Zerstörbare Korkklötze aus dem Fahrzeug-Kit bleiben separat; keine neue Zerstörungsregel in diesem Paket.

## Nutzung
```js
container.innerHTML = ToyboxBlocks.svg('block-roof-round-red', {
  size: 128, angle: 0, shadow: false
});
// Optional: Daten in die vorherige Bibliothek einfügen.
ToyboxBlocks.installInto(ToyboxAssets);
```
Das vorhandene Canvas-Layer-Vorladen kann dann mit den neuen Definitionen arbeiten. Die Einfügefunktion ergänzt nur Renderdaten; keine Spielzustände oder Regeln.
Schatten gehören auf die Bodenebene. Bei Turm+Dach nicht mehrere Schatten übereinander stapeln.

## Prüfung
SVG-XML, PNG-Dateiintegrität, JS-Syntax und SVG-Erzeugung mit Node geprüft.
Kein echter Browsertest, keine file://-Kompatibilitätszusage, keine Prüfung im Originalspiel.
Bunte Burg ist eine reine Kompositionsstudie, kein validiertes Kartengitter.
Die große Farbpalette dient der Auswahl. Für echte Räume weniger Akzentfarben wählen, damit blaue/orange Spieler gegenüber der Umgebung lesbar bleiben.
