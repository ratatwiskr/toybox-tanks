# Toybox Tanks – Top-down asset study

## Scope
Sixteen visual assets. Design proposal only. No game project source was provided or modified.

## Files
- toybox-assets.js: dependency-free source definitions and browser API.
- toybox-asset-pruefstand.html: self-contained inspection page; SVG + Canvas layer view.
- svg/: independent transparent SVG files in default pose.
- assets.json: source markup, layer roles and metadata.
- previews/: rendered contact sheet and illustrative room, as PNG and SVG.

## Conventions
viewBox="-64 -64 128 128"; origin and pivots at (0,0); forward direction right.
API angles are degrees, positive clockwise, not simulation radians.
Asset size means the whole 128-unit source canvas, including transparent margins.
The body, aim and loaded layers can be rendered independently. Loaded follows aim.
Fixed parts do not rotate. Whole environment blocks may be rotated by an outer transform.
Shadows are separate and screen-oriented. No perspective side faces.
Metadata bounds describe visuals, not authoritative gameplay collision geometry.

## SVG use
```js
container.innerHTML = ToyboxAssets.svg('tank-blue', {
  bodyAngle: 20, aimAngle: -35, size: 128
});
```

## Canvas use
Preload once. Do not decode SVG or construct images every frame.
```js
const layers = await ToyboxAssets.prepareLayers('tank-blue', 256);
// In the render function, after world-to-screen setup:
ToyboxAssets.drawLayers(ctx, layers, x, y, 128, {
  bodyAngle: 20, aimAngle: -35
});
```
The layer drawing helper intentionally excludes shadow/debug overlays.
Draw contact shadows as separate ground effects if required.
For strict procedural-only rendering the SVG paths can instead be translated to Canvas drawing functions; this study proposes SVG as an optional rendering source, not an engine change.

## New mechanics not implemented
No HP, enemy movement, catapult physics, chick targeting or destructible terrain logic.
All cork damage states retain the same rectangular visual footprint.
If destruction is later approved, its effects must be consistent across movement, projectiles and line of sight. No debris collisions are implied.
The chick is a single source pose; no walking animation yet.
The catapult arm is a separate source layer, not a completed launch animation.
Catapult independent aim rotation is available for inspection, not specified gameplay.

## Validation
SVG XML parsing and CairoSVG PNG rendering; PNG file integrity checks; JavaScript syntax and SVG-generation smoke tests if Node is available.
No real-browser or actual file:// compatibility test; no gameplay or original-renderer integration test. Previews validate output generation, not art quality.
