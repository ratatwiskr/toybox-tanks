# Toybox Tanks – Kinderzimmerboden

Drei wiederholbare 512×512-SVG-Bodenkacheln: warmes Holz, helles Holz, gedeckter Teppichboden. Separater transparenter Spielteppich (480×320) als optionale Dekoration.
Keine Möbel, Schatten oder Gameplay-Objekte in den Bodenkacheln. Keine Geschwindigkeitsänderung, Kollision oder Navigation durch den Teppich. Illustrative Varianten, kein nachgewiesener Implementierungsstand.

## Dateien
- toybox-floors.js: Quellen und SVG-/Canvas-API.
- toybox-fussboden-pruefstand.html: eigenständige SVG- und Canvas-Vorschau.
- tiles/: einzelne wiederholbare SVG-Kacheln.
- decoration/rug-road.svg: transparenter Spielteppich.
- previews/: gerenderte Ansichten und Vergleich.

## Canvas
```js
const floor = await ToyboxFloors.prepare(ctx, 'wood-warm');
const rug = await ToyboxFloors.prepareRug();
// Nach der bestehenden Welt-zu-Bildschirm-Transformation:
ToyboxFloors.draw(ctx, floor, 0, 0, worldWidth, worldHeight);
ctx.drawImage(rug, rugX, rugY);
// Danach Bodenschatten, Deckung, Fahrzeuge und Effekte zeichnen.
```
Einmal vorladen; keine SVG-Dekodierung pro Frame. Pattern-Ursprung ist Weltursprung; Boden nicht an Fahrzeugbewegung koppeln. Nicht die bestehende logische Arena oder DPR-Anpassung ändern.
Die 512 logischen Einheiten sind ein Ausgangswert der Grafikstudie, kein festgelegtes Gameplay-Maß. Mustergröße bei Integration bewusst an vorhandene Weltmaße anpassen.

## Gestaltung
Geringer Kontrast, schmale Fugen, dezente Maserung. Keine schwarzen Straßenränder oder Wandkonturen auf dem Spielteppich. Der Teppich ist bewusst ruhig und kann ganz weggelassen oder am Arenarand platziert werden. Lesbarkeit mit Fahrzeugen und Warnmarkierungen muss im Originalspiel separat geprüft werden.

## Nachweise
SVG-XML, PNG-Integrität, JS-Syntax und SVG-Ausgaben geprüft. Kein echter Browsertest, keine file://-Kompatibilitätszusage, keine Integration in vorhandene Projektdateien.
